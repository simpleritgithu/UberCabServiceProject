package com.ex.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UberCabServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UberCabServiceApplication.class, args);
	}

}
