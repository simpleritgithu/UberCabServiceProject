package com.ex.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ex.demo.Entity.Ride;
import com.ex.demo.Exception.RideNotFoundException;
import com.ex.demo.Repository.RideRepository;

import java.util.List;

@Service
public class RideService {
	@Autowired
	private RideRepository rideRepository;

	public Ride createRide(Ride ride) {
		return rideRepository.save(ride);
	}

	public List<Ride> getRidesByUserId(Long userId) {
		return rideRepository.findByUserId(userId);
	}

	public Ride getRideById(Long id) {
		return rideRepository.findById(id)
				.orElseThrow(() -> new RideNotFoundException("Ride not found with id: " + id));
	}

	public void deleteRide(Long id) {
		rideRepository.deleteById(id);
	}
}
