package com.ex.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverService1Application {

	public static void main(String[] args) {
		SpringApplication.run(DriverService1Application.class, args);
	}

}
